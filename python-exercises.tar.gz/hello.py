# -*- coding: utf-8 -*-
"""
Created on Thu Sep 10 20:23:14 2015

@author: rob

"""

print('Hello World!')
