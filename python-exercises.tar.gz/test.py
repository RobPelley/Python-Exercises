# -*- coding: utf-8 -*-
"""
Created on Thu Sep 10 20:35:24 2015

@author: rob

"""

firstname = input('First Name : ')
lastname = input('Last Name  : ')

name = firstname + ' ' + lastname

print(name)
round()